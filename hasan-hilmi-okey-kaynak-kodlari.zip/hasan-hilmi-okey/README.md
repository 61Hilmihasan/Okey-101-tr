# Hasan Hilmi Yılmaz Okey — başlangıç kaynak kodu

Bu depo, Klasik Okey + 101 Okey için geliştirilebilir bir MVP iskeletidir.
İçerik: TypeScript oyun motoru, Socket.IO sunucusu ve Expo React Native istemcisi.

## Gereksinimler
- Node.js 20+
- npm
- Android Studio (Android derlemek için)
- macOS + Xcode (iOS derlemek için; App Store gönderimi için gereklidir)

## Kurulum
1. `cd server && npm install`
2. `cp .env.example .env`
3. `npm run dev`
4. Yeni terminal: `cd mobile && npm install`
5. `npx expo start`

Mobil uygulamadaki sunucu adresini `mobile/src/config.ts` içinden değiştirin.
Gerçek telefonda `localhost` yerine bilgisayarınızın yerel ağ IP adresini yazın.

## Mevcut durum
- 106 taşlık set (iki standart takım + iki sahte okey)
- Taşları karıştırma ve başlangıç dağıtımı
- Klasik/101 oyun odası oluşturma ve Socket.IO ile odaya katılma
- Sunucu tarafında sıra, taş çekme ve taş atma için başlangıç akışı
- Basit mobil oda oluşturma/katılma ekranı

## Yayına çıkmadan önce tamamlanması gerekenler
Bu proje mağazaya gönderilmeye hazır bitmiş ürün değildir. Aşağıdakiler eklenmeli:
- Tam Klasik Okey ve 101 Okey kuralları, per/seri doğrulama, gösterge/okey hesabı,
  101 açma ve el bitirme/puanlama, ceza ve tur yönetimi
- Kimlik doğrulama, parola sıfırlama, e-posta/telefon doğrulama
- PostgreSQL kalıcı kullanıcı/istatistik verisi, Redis ölçekleme ve oda kurtarma
- Hile önleme, hız sınırlama, moderasyon/şikâyet, gizlilik ve KVKK metinleri
- Otomatik testler, yük testleri, izleme, yedekleme ve güvenlik denetimi
- Apple/Google geliştirici hesapları, mağaza görselleri ve politika incelemesi

Lisans ve marka: Proje başlangıç kodu olarak sağlanır. Kullanılan kütüphanelerin lisanslarını
kontrol edin. "Hasan Hilmi Yılmaz Okey" marka adı ve logo kullanım haklarını ayrıca doğrulayın.
