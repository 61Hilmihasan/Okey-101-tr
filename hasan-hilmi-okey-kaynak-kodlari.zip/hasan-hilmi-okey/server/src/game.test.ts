import { describe, it, expect } from "vitest";
import { makeTileSet, shuffle, createRoom, startRoom } from "./game.js";

describe("Okey game engine", () => {
  it("creates 106 tiles", () => expect(makeTileSet()).toHaveLength(106));
  it("shuffles without losing tiles", () => {
    const a = makeTileSet(); const b = shuffle(a);
    expect(b).toHaveLength(a.length);
    expect(new Set(b.map(t => t.id)).size).toBe(106);
  });
  it("deals 15 to first player and 14 to others", () => {
    const room = createRoom("CLASSIC", "TEST");
    room.players = [1,2,3,4].map(n => ({id:String(n),name:`P${n}`,hand:[]}));
    const started = startRoom(room);
    expect(started.players.map(p => p.hand.length)).toEqual([15,14,14,14]);
  });
});
