export type GameType = "CLASSIC" | "OK101";
export type Color = "red" | "blue" | "black" | "yellow";
export type Tile = { id: number; color: Color | "fake"; number: number; fake?: boolean };
export type Player = { id: string; name: string; hand: Tile[] };
export type Room = {
  id: string; type: GameType; players: Player[]; stock: Tile[];
  discard: Tile[]; currentTurn: number; started: boolean; indicator?: Tile;
};

const COLORS: Color[] = ["red", "blue", "black", "yellow"];

export function makeTileSet(): Tile[] {
  const tiles: Tile[] = [];
  let id = 1;
  for (const color of COLORS) {
    for (let number = 1; number <= 13; number++) {
      for (let copy = 0; copy < 2; copy++) tiles.push({ id: id++, color, number });
    }
  }
  // Two sahte okey tiles; their display/meaning is resolved from the indicator.
  tiles.push({ id: id++, color: "fake", number: 0, fake: true });
  tiles.push({ id, color: "fake", number: 0, fake: true });
  return tiles;
}

export function shuffle<T>(items: T[]): T[] {
  const a = [...items];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function createRoom(type: GameType, id: string): Room {
  return { id, type, players: [], stock: [], discard: [], currentTurn: 0, started: false };
}

export function startRoom(room: Room): Room {
  if (room.players.length !== 4) throw new Error("Oyun için tam 4 oyuncu gerekli.");
  const deck = shuffle(makeTileSet());
  // One tile is revealed as indicator. Okey identity is indicator + 1, wrapping 13 -> 1.
  const indicator = deck.pop()!;
  const hands = room.players.map((p, index) => ({
    ...p, hand: deck.splice(0, index === 0 ? 15 : 14)
  }));
  return { ...room, players: hands, indicator, stock: deck, discard: [], currentTurn: 0, started: true };
}

export function drawTile(room: Room, playerId: string, fromDiscard = false): Room {
  if (!room.started) throw new Error("Oyun başlamadı.");
  const current = room.players[room.currentTurn];
  if (!current || current.id !== playerId) throw new Error("Sıra sizde değil.");
  const pile = fromDiscard ? room.discard : room.stock;
  if (!pile.length) throw new Error("Taş kalmadı.");
  const tile = pile.pop()!;
  const players = room.players.map(p => p.id === playerId ? { ...p, hand: [...p.hand, tile] } : p);
  return { ...room, players, stock: fromDiscard ? room.stock : pile, discard: fromDiscard ? pile : room.discard };
}

export function discardTile(room: Room, playerId: string, tileId: number): Room {
  if (!room.started) throw new Error("Oyun başlamadı.");
  const current = room.players[room.currentTurn];
  if (!current || current.id !== playerId) throw new Error("Sıra sizde değil.");
  const player = room.players.find(p => p.id === playerId)!;
  const tile = player.hand.find(t => t.id === tileId);
  if (!tile) throw new Error("Bu taş elinizde değil.");
  const players = room.players.map(p => p.id === playerId
    ? { ...p, hand: p.hand.filter(t => t.id !== tileId) } : p);
  return { ...room, players, discard: [...room.discard, tile],
    currentTurn: (room.currentTurn + 1) % 4 };
}
