import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "node:http";
import { Server } from "socket.io";
import { z } from "zod";
import { createRoom, startRoom, drawTile, discardTile, type Room, type GameType } from "./game.js";

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") ?? "*" }));
app.use(express.json());
app.get("/health", (_req, res) => res.json({ ok: true, service: "Hasan Hilmi Yılmaz Okey" }));

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: process.env.CLIENT_ORIGIN?.split(",") ?? "*" } });
const rooms = new Map<string, Room>();
const CreateSchema = z.object({ type: z.enum(["CLASSIC", "OK101"]), name: z.string().min(2).max(24) });

io.on("connection", socket => {
  socket.on("room:create", (raw, ack) => {
    const parsed = CreateSchema.safeParse(raw);
    if (!parsed.success) return ack?.({ error: "Geçersiz oda bilgisi." });
    const id = Math.random().toString(36).slice(2, 9).toUpperCase();
    const room = createRoom(parsed.data.type as GameType, id);
    room.players.push({ id: socket.id, name: parsed.data.name, hand: [] });
    rooms.set(id, room);
    socket.join(id);
    ack?.({ roomId: id, room: publicRoom(room) });
  });

  socket.on("room:join", ({ roomId, name }, ack) => {
    const room = rooms.get(String(roomId).toUpperCase());
    if (!room) return ack?.({ error: "Oda bulunamadı." });
    if (room.started || room.players.length >= 4) return ack?.({ error: "Oda dolu veya oyun başladı." });
    if (typeof name !== "string" || name.trim().length < 2) return ack?.({ error: "İsim en az 2 karakter olmalı." });
    room.players.push({ id: socket.id, name: name.trim().slice(0,24), hand: [] });
    socket.join(room.id);
    rooms.set(room.id, room);
    io.to(room.id).emit("room:update", publicRoom(room));
    ack?.({ roomId: room.id, room: publicRoom(room) });
  });

  socket.on("game:start", ({ roomId }, ack) => {
    const room = rooms.get(String(roomId).toUpperCase());
    if (!room) return ack?.({ error: "Oda bulunamadı." });
    try {
      const started = startRoom(room);
      rooms.set(room.id, started);
      sendPrivateStates(started);
      ack?.({ ok: true });
    } catch (e) { ack?.({ error: e instanceof Error ? e.message : "Oyun başlatılamadı." }); }
  });

  socket.on("game:draw", ({ roomId, fromDiscard }, ack) => {
    const room = rooms.get(String(roomId).toUpperCase());
    if (!room) return ack?.({ error: "Oda bulunamadı." });
    try {
      const updated = drawTile(room, socket.id, Boolean(fromDiscard));
      rooms.set(room.id, updated); sendPrivateStates(updated); ack?.({ ok: true });
    } catch (e) { ack?.({ error: e instanceof Error ? e.message : "Taş çekilemedi." }); }
  });

  socket.on("game:discard", ({ roomId, tileId }, ack) => {
    const room = rooms.get(String(roomId).toUpperCase());
    if (!room) return ack?.({ error: "Oda bulunamadı." });
    try {
      const updated = discardTile(room, socket.id, Number(tileId));
      rooms.set(room.id, updated); sendPrivateStates(updated); ack?.({ ok: true });
    } catch (e) { ack?.({ error: e instanceof Error ? e.message : "Taş atılamadı." }); }
  });

  socket.on("disconnect", () => {
    for (const [id, room] of rooms) {
      if (!room.started) {
        room.players = room.players.filter(p => p.id !== socket.id);
        if (!room.players.length) rooms.delete(id);
        else io.to(id).emit("room:update", publicRoom(room));
      }
    }
  });
});

function publicRoom(room: Room) {
  return { id: room.id, type: room.type, players: room.players.map(p => ({ id:p.id, name:p.name })),
    started: room.started, currentTurn: room.currentTurn, stockCount: room.stock.length };
}
function sendPrivateStates(room: Room) {
  for (const player of room.players) {
    io.to(player.id).emit("game:state", {
      ...publicRoom(room),
      hand: player.hand,
      indicator: room.indicator,
      discardTop: room.discard.at(-1) ?? null,
      isMyTurn: room.players[room.currentTurn]?.id === player.id
    });
  }
}

const port = Number(process.env.PORT ?? 3000);
httpServer.listen(port, () => console.log(`Okey sunucusu ${port} portunda çalışıyor.`));
