export const SERVER_URL = "http://192.168.1.10:3000"; // Kendi bilgisayarınızın yerel IP adresiyle değiştirin.
