import React, { useEffect, useState } from "react";
import { SafeAreaView, View, Text, TextInput, Pressable, StyleSheet, FlatList } from "react-native";
import { io, Socket } from "socket.io-client";
import { SERVER_URL } from "./src/config";

type RoomInfo = { id: string; type: string; players: { id: string; name: string }[]; started: boolean };
let socket: Socket;

export default function App() {
  const [name, setName] = useState("");
  const [roomId, setRoomId] = useState("");
  const [room, setRoom] = useState<RoomInfo | null>(null);
  const [status, setStatus] = useState("Sunucuya bağlanılıyor...");
  const [hand, setHand] = useState<any[]>([]);
  const [myTurn, setMyTurn] = useState(false);

  useEffect(() => {
    socket = io(SERVER_URL, { transports: ["websocket"] });
    socket.on("connect", () => setStatus("Bağlandı"));
    socket.on("connect_error", () => setStatus("Sunucu bağlantısı kurulamadı"));
    socket.on("room:update", setRoom);
    socket.on("game:state", (state) => {
      setRoom(state); setHand(state.hand ?? []); setMyTurn(Boolean(state.isMyTurn));
    });
    return () => { socket.disconnect(); };
  }, []);

  const create = (type: "CLASSIC" | "OK101") => socket.emit("room:create", { type, name }, (r: any) => {
    if (r.error) setStatus(r.error); else { setRoom(r.room); setRoomId(r.roomId); setStatus("Oda kodu: " + r.roomId); }
  });
  const join = () => socket.emit("room:join", { roomId, name }, (r: any) => {
    if (r.error) setStatus(r.error); else { setRoom(r.room); setStatus("Odaya katıldın: " + r.roomId); }
  });
  const start = () => socket.emit("game:start", { roomId: room?.id }, (r: any) => setStatus(r.error ?? "Oyun başlatıldı"));
  const draw = () => socket.emit("game:draw", { roomId: room?.id, fromDiscard: false }, (r: any) => r.error && setStatus(r.error));
  const discard = (id: number) => socket.emit("game:discard", { roomId: room?.id, tileId: id }, (r: any) => r.error && setStatus(r.error));

  return <SafeAreaView style={s.page}>
    <Text style={s.brand}>HASAN HİLMİ YILMAZ</Text>
    <Text style={s.heading}>OKEY</Text>
    <Text style={s.status}>{status}</Text>
    <TextInput style={s.input} placeholder="Oyuncu adın" value={name} onChangeText={setName} />
    {!room && <>
      <Text style={s.section}>Oyun türü seç</Text>
      <Pressable style={s.button} onPress={() => create("CLASSIC")}><Text style={s.buttonText}>Klasik Okey Masası Kur</Text></Pressable>
      <Pressable style={s.button} onPress={() => create("OK101")}><Text style={s.buttonText}>101 Okey Masası Kur</Text></Pressable>
      <TextInput style={s.input} placeholder="Oda kodu" autoCapitalize="characters" value={roomId} onChangeText={setRoomId} />
      <Pressable style={s.secondary} onPress={join}><Text style={s.buttonText}>Odaya Katıl</Text></Pressable>
    </>}
    {room && <>
      <Text style={s.section}>{room.type === "CLASSIC" ? "Klasik Okey" : "101 Okey"} · Oda {room.id}</Text>
      <Text style={s.info}>Oyuncular: {room.players?.map(p => p.name).join(", ")}</Text>
      {!room.started && <Pressable style={s.button} onPress={start}><Text style={s.buttonText}>Oyunu Başlat (4 oyuncu)</Text></Pressable>}
      {room.started && <>
        <Text style={s.info}>{myTurn ? "Sıra sende: önce taş çek." : "Diğer oyuncunun sırası."}</Text>
        <Pressable style={s.secondary} onPress={draw} disabled={!myTurn}><Text style={s.buttonText}>Taş Çek</Text></Pressable>
        <FlatList horizontal data={hand} keyExtractor={t => String(t.id)} renderItem={({item}) =>
          <Pressable style={s.tile} onPress={() => discard(item.id)}><Text style={s.tileText}>{item.fake ? "Sahte" : item.number}</Text><Text>{item.color}</Text></Pressable>} />
        <Text style={s.info}>Taşa dokunarak at (oyun sırası sendeyse).</Text>
      </>}
    </>}
  </SafeAreaView>;
}
const s = StyleSheet.create({
  page:{flex:1,backgroundColor:"#0b573b",padding:20,gap:12},
  brand:{color:"#f5d77a",fontSize:16,fontWeight:"800",textAlign:"center",marginTop:18},
  heading:{color:"white",fontSize:38,fontWeight:"900",textAlign:"center"},
  status:{color:"#e5f4eb",textAlign:"center"},
  input:{backgroundColor:"white",padding:14,borderRadius:10,fontSize:16},
  section:{color:"#fff",fontWeight:"800",fontSize:19,marginTop:10},
  button:{backgroundColor:"#d7a83e",padding:15,borderRadius:10,alignItems:"center"},
  secondary:{backgroundColor:"#235eaa",padding:15,borderRadius:10,alignItems:"center"},
  buttonText:{color:"white",fontWeight:"800"},
  info:{color:"white"},
  tile:{backgroundColor:"#fff",padding:12,borderRadius:8,margin:5,minWidth:54,alignItems:"center"},
  tileText:{fontSize:22,fontWeight:"900"}
});
